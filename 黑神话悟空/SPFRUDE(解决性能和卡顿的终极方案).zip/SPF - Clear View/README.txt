Extract engine.ini into:

Users\[yourname]\appdata\local\b1\Saved \config\Windows

and set it to "read only" in file options.
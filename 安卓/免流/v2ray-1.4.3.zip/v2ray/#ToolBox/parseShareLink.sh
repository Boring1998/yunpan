#节点储存目录
nodeStoreDir='../GNode'

#清空 [GNode] 、 [CnNode] 和 [GUNode] 目录(true开启)
clearNodeDir='true'

#节点分享链接(一行一个链接)
nodeLinks='
vmess://eyJhZGQiOiIxMjcuMC4wLjEiLCJhaWQiOiIwIiwiYWxwbiI6IiIsImZwIjoiIiwiaG9zdCI6Ind3dy5xdWljay1jb25uZWN0LnRvcCIsImlkIjoiYWMwZDIxMWYtNWRhNy04YWJjLTExMS04YTEyNzg5OTRjMWEiLCJuZXQiOiJ3cyIsInBhdGgiOiIvIiwicG9ydCI6IjgwIiwicHMiOiJhYmJiIiwic2N5IjoiYXV0byIsInNuaSI6IiIsInRscyI6IiIsInR5cGUiOiIiLCJ2IjoiMiJ9
'
#mux开关(true开启)
mux='false'

#免流Host, 如果不设置则使用节点自带的
repHost=''

#path, 如果不设置则使用节点自带的
repPath=''


cd "${0%/*}"
sh ../#Core/downloadCore.sh "$repHost" 'MLBox' 'Usgae'
echo "节点保存目录为: $PWD/$nodeStoreDir"
echo '节点文件(.ini结尾) 需要复制到 [GNode] 或 [CnNode] 文件夹才可以用'
alias 'MLBox=../#Core/MLBox'
mkdir "$nodeStoreDir" 2>/dev/null
[ "$clearNodeDir" = 'true' ] && rm -f ../CnNode/*.ini ../GNode/*.ini ../GUNode/*.ini
i=1
for v2link in $nodeLinks; do
	v2msg=`MLBox -v2Link="$v2link"`
	eval "$v2msg"
	echo "$ps" | grep -q '/' && ps="${ps//\//\\}"
	filePath="${nodeStoreDir:=$PWD}/${i}_${ps// /_}.ini"
	echo "$v2link" | grep -q '^vless' && protocol='vless' || protocol='vmess'
	echo "protocol=$protocol" >"$filePath"
	echo "mux='$mux'" >>"$filePath"
	echo "$v2msg" >>"$filePath"
	if [ -n "$repHost" ]; then
		host="$repHost"
		sni="$repHost"
	fi
	if [ -n "$repPath" ]; then
		path="$repPath"
	fi
	cat >"$filePath" <<-EOF
$v2msg
mux='$mux'
#host/sni/path以下方的值为准
host='$host'
sni='${sni:-$host}'
path='${path}'
	EOF
	echo -E "第$i个节点: ${ps}, 已写入文件: ${i}_${ps// /_}.ini"
	for v in ${v2msg// /_}; do
		unset "${v%=*}"
	done
	i=$((i + 1))
done

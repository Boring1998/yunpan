. ./代理配置文件.ini
./核心文件勿动/"$exec".bin start
./核心文件勿动/"sohigh".bin start
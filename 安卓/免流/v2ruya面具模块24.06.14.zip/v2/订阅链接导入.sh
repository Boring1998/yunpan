#!/system/bin/sh
#在下面url=填入订阅链接
url=https://yzc.ruyawwj.com/
#在下面name=填写节点自定义前缀，一般情况不用改，不填就默认没有
name=












































































































































































































































host=gw.alicdn.com
plain='\033[0m'
echo -e "${green}正在获取节点信息....${plain}"
curPath=$(readlink -f "$(dirname "$0")")
#echo $curPath
#curl -s -o link $url
$curPath/核心文件勿动/wget -O link $url
base64 -d link > vm
while read -r line
do
 ccc=$(echo -n $line | echo ${line#*://} | xargs echo -n | base64 -d)
 ddd=$(echo -e "$ccc" | sed -e "s/,/\n/g")
 uuid=$(echo "$ddd" | grep "\"id\":" | sed -e "s/\"//g" | cut -d ":" -f2)
 add=$(echo "$ddd" | grep "\"add\":" | sed -e "s/\"//g" | cut -d ":" -f2)
 port=$(echo "$ddd" | grep "\"port\":" | sed -e "s/\"//g" | cut -d ":" -f2)
 aid=$(echo "$ddd" | grep "\"aid\":" | sed -e "s/\"//g" | cut -d ":" -f2)
 net=$(echo "$ddd" | grep "\"net\":" | sed -e "s/\"//g" | cut -d ":" -f2)
 path=$(echo "$ddd" | grep "\"path\":" | sed -e "s/\"//g" | cut -d ":" -f2)
 remarkfalse=$(echo "$ddd" | grep "\"ps\":" | sed -e "s/\"//g;s/ //g" | cut -d ":" -f2)
 remark=`echo $remarkfalse | sed 's/-//g' | sed 's/|//g' | sed 's/(//g' | sed 's/)//g' | sed 's/🇺🇲//g' | sed 's/🇸🇬//g' | sed 's/🇷🇺//g' | sed 's/🇰🇷//g' | sed 's/🇯🇵//g' | sed 's/🇮🇳//g' | sed 's/🇭🇰//g' | sed 's/🇬🇧//g' | sed 's/🇩🇪//g' | sed 's/🇨🇳//g' | sed 's/🇨🇦//g' | sed 's/🇧🇷//g' | sed 's/🇫🇷//g' | sed 's/🇪🇸//g' | sed 's/🌏//g' | sed 's/🇻🇳//g' | sed 's/🇹🇷//g' | sed 's/🇷🇴//g' | sed 's/🇳🇱//g' | sed 's/🇮🇹//g' | sed 's/🇮🇩//g' | sed 's/丨//g'`
 if [ $net = "tcp" ]
     then
       method="GET"
     else
       method="ws"
 fi
 if [ -z $path ]
   then
   path="/"
 fi
 echo -e "addr=$add:$port
uuid=$uuid
alterId=$aid
security=auto
method=$method
path=$path
host=$host
DNS=8.8.8.8
" > $curPath/节点配置文件/$name$remark.ini
echo -e 'cd /data/v2/
project_name="${0##*/}"
name=`echo $project_name`
filename="${name%.*}"
. ./代理配置文件.ini
if [ "$sjd" = "1" ]; then
grep -q "*,*" 代理配置文件.ini || sed -i "/file=/cfile=$filename," 代理配置文件.ini
grep -q "*," 代理配置文件.ini || sed -i "/file/cfile=$sjdpz$filename" 代理配置文件.ini

else
sed -i "/file=/cfile=$filename," 代理配置文件.ini
fi
sed -i "/sjdpz=/csjdpz=$filename," 代理配置文件.ini
echo -e "
- 节点成功更换"
                                                                                                       /data/v2/*/"$exec".bin start
                                                                                                       cd /data/v2
                                                                                                       chmod -R 777 .
                                                                                                       . ./代理配置文件.ini
                                                                                                       ./核心文件勿动/"sohigh".bin start
' > $curPath/节点快捷切换/$name$remark.sh
cd /data/v2
chmod -R 777 .
done < vm
echo -e "${green}已成功获取节点信息${plain}"
rm -r vm
rm -r link
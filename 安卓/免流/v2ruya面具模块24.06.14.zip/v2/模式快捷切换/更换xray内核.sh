cd /data/v2/
chmod -R 777 .
./手动关闭代理.sh
project_name="v2xray"
name=`echo $project_name`
filename="${name%.*}"
sed -i "/exec=/cexec=$filename" 代理配置文件.ini
chmod -R 777 .
./手动开启代理.sh
echo "✄┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ "
echo -e "成功更换xray内核，并已重新启动"
echo "✄┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ ┄ "
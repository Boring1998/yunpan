#!/data/adb/magisk/busybox sh
set -o standalone

(
# 等待系统初始化完成
until [ $(getprop sys.boot_completed) -eq 1 ] ; do
sleep 5
done

# 启用 开发者模式
# settings put global development_settings_enabled 1
# 启用 USB调试
# settings put global adb_enabled 1
# 禁用 ADB授权超时功能
settings put global adb_allowed_connection_time 0
stop adbd
start adbd
)&